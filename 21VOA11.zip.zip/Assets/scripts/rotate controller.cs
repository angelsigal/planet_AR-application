using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rotatecontroller : MonoBehaviour
{
   // this variable is used for attaching game object
    public GameObject planetobject;
    public Vector3 rotationvector;

    // Update is called once per frame
    void Update()
    {
       planetobject.transform.Rotate(rotationvector * Time.deltaTime); 
    }
}
